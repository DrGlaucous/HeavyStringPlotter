#pragma once

void enable_core0_WDT();
void disable_core0_WDT();
