#include "ledc_struct.h"

ledc_dev_t LEDC;
