# stringent
Stringent - The Wall Plotter

For more info look at: [Project on hackster.io](https://www.hackster.io/fredrikstridsman/stringent-the-15-wall-plotter-d965ca) 
